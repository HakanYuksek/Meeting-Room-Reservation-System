﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MeetingRoomReservation.Models
{
    public class Location
    {
        [Key]
        public int LocationID { get; set; }
        public virtual List<MeetingRoom> meetingRooms { get; set; }
        [Required]
        public String locationName { get; set; }
        public Location()
        {
            meetingRooms = new List<MeetingRoom>();
        }
    }
}