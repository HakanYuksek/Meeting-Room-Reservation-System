namespace MeetingRoomReservation.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;
    using MeetingRoomReservation.Roles;

    public partial class MeetingDBContext : DbContext
    {
        public MeetingDBContext()
            : base("name=MeetingDBContext")
        {
        }

        public virtual DbSet<Location> Locations { get; set; }
        public virtual DbSet<MeetingRoom> MeetingRooms { get; set; }
        public virtual DbSet<Meeting> Meetings { get; set; }
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<UserAndMeeting> UserAndMeetings { get; set; }
        public virtual DbSet<Notification> Notifications { get; set; }
        public virtual DbSet<UserAndNotification> UserAndNotifications { get; set; }
    }
}
