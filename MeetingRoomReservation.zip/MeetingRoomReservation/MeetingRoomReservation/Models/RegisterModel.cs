﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MeetingRoomReservation.Models
{
    public class RegisterModel
    {
        public String Username { get; set; }
        public String FullName{ get; set; }
        public String Password { get; set; }
        public String Rpassword { get; set; }
        public String Email { get; set; }
        public Boolean Check { get; set; }
    }
}