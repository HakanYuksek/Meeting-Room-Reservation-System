﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MeetingRoomReservation.Models
{
    public class Notification
    {
        [Key]
        public int NotificationID { get; set; }
        public int MeetingID { get; set; }
        public String Message { get; set; }
        public DateTime TimeOfSentIt { get; set; }



    }
}