﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MeetingRoomReservation.Models
{
    public class LoginModel
    {
        [Required(ErrorMessage ="Please, enter the your username")]
        public String Username { get; set; }
        [Required(ErrorMessage = "Please, enter the your password")]
        [DataType(DataType.Password)]
        public String Password { get; set; }
        public bool RememberMe { get; set; }

    }
}