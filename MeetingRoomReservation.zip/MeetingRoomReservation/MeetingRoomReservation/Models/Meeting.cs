﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MeetingRoomReservation.Models
{
    public class Meeting
    {
        [Key]
        public int MeetingID { get; set; }
        [Required]
        public int MeetingRoomID { get; set; }
        public int OwnerID { get; set; }
        public virtual MeetingRoom meetingRoom { get; set; }
        [DataType(DataType.DateTime)]
        public DateTime beginning_of_meeting{ get; set;}
        [DataType(DataType.DateTime)]
        public DateTime end_of_meeting { get; set; }
        public bool? Approval_information { get; set; }
        public virtual List<User> participants { get; set; }
        public Meeting()
        {
            participants = new List<User>();
        }
        
    }
}