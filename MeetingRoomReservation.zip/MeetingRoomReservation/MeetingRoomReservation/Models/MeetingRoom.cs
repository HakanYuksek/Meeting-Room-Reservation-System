﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MeetingRoomReservation.Models
{
    public class MeetingRoom
    {
        [Key]
        public int MeetingRoomID { get; set; }
        [Required]
        public String RoomName { get; set; }
        public int LocationID { get; set; }
        public int capacity { get; set; }
        public virtual Location Location { get; set; }
    }
}