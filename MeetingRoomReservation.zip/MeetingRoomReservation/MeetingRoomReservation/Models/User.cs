﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MeetingRoomReservation.Models
{
    public class User
    {
        [Key]
        public int UserID { get; set; }
        [Required]
        public String Username { get; set; }
        [Required]
        public String Fullname { get; set; }
        [Required]
        public String Password { get; set; }
        [Required]
        public String Email { get; set; }
        public virtual List<Meeting> meeting { get; set; }   
        public String role { get; set; }
        public User()
        {
            meeting = new List<Meeting>();
        }
    }
}