﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using MeetingRoomReservation.Models;
using Microsoft.AspNet.SignalR;

namespace MeetingRoomReservation.App_Start
{
    public class MeetingRoomHub : Hub
    {
        public void LoadTheMeetings(String Username)
        {
            MeetingDBContext db = new MeetingDBContext();
            List<Meeting> meetingsToday = db.Meetings.ToList();
            meetingsToday = meetingsToday.Where(x => x.beginning_of_meeting.DayOfYear == DateTime.Now.DayOfYear).ToList();
            //gun icerisinde baslayacak olan toplantilar meetingsToday listesine kaydedildi...
            foreach (var item in meetingsToday) {
                Meeting meeting = db.Meetings.Find(item.MeetingID);
                MeetingRoom meetingRoom = db.MeetingRooms.Find(meeting.MeetingRoomID);
                Location location = db.Locations.Find(meetingRoom.LocationID);
                DateTime now = DateTime.Now;
               if (meeting.beginning_of_meeting.CompareTo(DateTime.Now)>=0) {
                    TimeSpan time= meeting.beginning_of_meeting-DateTime.Now;
                    if (time.TotalMinutes <= 15)
                    {
                          Notification notification = db.Notifications.Where(x => x.MeetingID == meeting.MeetingID).FirstOrDefault();
                          if (notification == null)//eger bu toplanti ile ilgili bir bildirim gonderilmemisse
                          {
                                notification = new Notification();
                                notification.MeetingID = meeting.MeetingID;
                                notification.TimeOfSentIt = DateTime.Now;
                                String intro = "Location is " + location.locationName + " and Room is " + meetingRoom.RoomName;
                                String date = "Beginning Time: " + meeting.beginning_of_meeting +
                                    " Ending Time: " + meeting.end_of_meeting;
                                notification.Message = intro + " " + date;
                                db.Notifications.Add(notification);
                                db.SaveChanges();
                                List<UserAndMeeting> parts = db.UserAndMeetings.Where(x => x.MeetingID == meeting.MeetingID).ToList();
                                foreach(var item1 in parts)//toplantiya katilacak olan butun kullanicilara bildirim gonderilir
                                {
                                    UserAndNotification a = new UserAndNotification();
                                    a.userID = item1.UserID;
                                    a.NotificationID = notification.NotificationID;
                                    db.UserAndNotifications.Add(a);
                                    db.SaveChanges();
                                }
                                //alttaki metot icerisinde kullanicinin MyNotification sayfasinda olup olmadigi kontrol edilir 
                                //cunku gelen bildirimler headBar da sayfa yenilenmeden gorunebiliyor
                                //ancak kullanici MyNotification sayfasinda gordugu bildirimler bu sayfaya actşon metodundan gonderildigi icin
                                //eski veriler oluyor
                                //eger biz herhangi yeni bir bildirim geldiginde kullanici bu sayfada ise sayfayi yeniliyoruz ki headbar daki bildirim
                                //ile burada gozuken bildirim verileri ortak olsun
                                Clients.Client(Context.ConnectionId).refreshMyNotificationPage();
                          }
                    }
                }
            }
            CleanNotification();
            ShowNotifications(Username);
        }
        public void ShowNotifications(String Username)
        {
            //bu metot headBar da bildirim geldiginde gosterilmesini saglar
            MeetingDBContext db = new MeetingDBContext();
            User user = db.Users.FirstOrDefault(x=>x.Username==Username);
            List<UserAndNotification> userAndNotifications = db.UserAndNotifications.Where(x => x.userID == user.UserID).ToList();
            foreach (var item in userAndNotifications)
            {
                Notification notification = db.Notifications.Find(item.NotificationID);
                Clients.Client(Context.ConnectionId).loadTheMeetings(notification.Message, notification.MeetingID,notification.NotificationID);
            }
            Clients.Client(Context.ConnectionId).num_of_meetings();
        }
        public void CleanNotification()
        {
            Clients.Client(Context.ConnectionId).cleanNotification();
        }
    }
}