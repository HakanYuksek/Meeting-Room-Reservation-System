﻿using System;
using System.Threading.Tasks;
using Microsoft.Owin;
using Owin;

[assembly: OwinStartup(typeof(MeetingRoomReservation.App_Start.MeetingRoomStartup))]

namespace MeetingRoomReservation.App_Start
{
    public class MeetingRoomStartup
    {
        public void Configuration(IAppBuilder app)
        {
            // Uygulamanızı nasıl yapılandıracağınız hakkında daha fazla bilgi için https://go.microsoft.com/fwlink/?LinkId=316888 adresini ziyaret edin
            app.MapSignalR();
        }
    }
}
