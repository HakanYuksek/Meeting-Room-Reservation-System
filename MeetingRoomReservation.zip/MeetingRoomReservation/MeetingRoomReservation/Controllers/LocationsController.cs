﻿using MeetingRoomReservation.Authentication;
using MeetingRoomReservation.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MeetingRoomReservation.Controllers
{
    [_SessionControl]
    public class LocationsController : Controller
    {
        MeetingDBContext db = new MeetingDBContext();

        public ActionResult List_The_Locations()
        {
            List<Location> locations = db.Locations.ToList();
            return View(locations);
        }

        public ActionResult Add_New_Location()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Add_New_Location(Location location)
        {
            if (location.locationName == null)//lokasyon adini bos bırakamaz
            {
                ViewBag.message = "Please enter the location name!!!";
            }
            else
            {
                var exist_location = db.Locations.FirstOrDefault(x => x.locationName == location.locationName);
                if (exist_location == null)//eklemek istedigimiz lokasyon listede var mi diye bakiyoruz,eger varsa  tekrardan yeni bir lokasyon ismi istiyoruz
                {
                    db.Locations.Add(location);
                    db.SaveChanges();
                    return RedirectToAction("List_The_Locations");
                }
                ViewBag.message = "There is the location with same name!!!";
            }
            return View("Add_New_Location");
        }
        //Delete fonksiyonu aldigi id ye gore lokasyonu bulup onu listeden siler
        public ActionResult Delete(int? id)
        {
            Location location = db.Locations.FirstOrDefault(x => x.LocationID == id);
            List<MeetingRoom> meetingRooms = db.MeetingRooms.Where(x => x.LocationID == location.LocationID).ToList();
            //oncelikle bu lokasyondaki butun toplantı odalarını silmemiz gerekiyor
            foreach (var item in meetingRooms)
            {
                item.Location = db.Locations.Find(item.LocationID);
                List<Meeting> meetings = db.Meetings.Where(x => x.MeetingRoomID == item.MeetingRoomID).ToList();
                //bu toplanti odasindaki butun toplantilar silinir
                foreach(var item1 in meetings)
                {
                    List<UserAndMeeting> userAndMeetings = db.UserAndMeetings.Where(x => x.MeetingID == item1.MeetingID).ToList();
                    Notification notification = db.Notifications.Where(x => x.MeetingID == item1.MeetingID).FirstOrDefault();
                    if (notification != null && item1.end_of_meeting.CompareTo(DateTime.Now) >= 0)
                    {
                        //bu toplanti ile ilgili bildirim gonderilmis mi diye kontrol ettik
                        //eger bu bildirim gonderilmis ise bu bildirimi silen katilimcilara da toplanti iptali hakkinda bildirim gonderilmelidir
                        foreach(var item2 in userAndMeetings)
                        {
                            if (db.UserAndNotifications.Where(x=>x.userID==item2.UserID).Where(y=>y.NotificationID==notification.NotificationID).FirstOrDefault()==null)
                            {
                                //bu toplantiya katilan kisilerden bildirimini silmis olanlara da toplanti iptali hakkinda bildirim gonderilmelidir
                                UserAndNotification userAndNotification = new UserAndNotification();
                                userAndNotification.NotificationID = notification.NotificationID;
                                userAndNotification.userID = item2.UserID;
                                db.UserAndNotifications.Add(userAndNotification);
                                db.SaveChanges();
                            }
                        }
                        notification.Message = "The Meeting where is in " + item.Location.locationName + "  " + item.RoomName +
                                                "  is cancelled!!!";
                        notification.TimeOfSentIt = DateTime.Now;
                    }
                    //bu toplanti ile ilgili bilgiler silinmeli
                    db.UserAndMeetings.RemoveRange(userAndMeetings);
                    db.Meetings.Remove(item1);
                }
                db.MeetingRooms.Remove(item);
            }
            //ardından bu lokasyonu silebiliriz
            db.Locations.Remove(location);
            db.SaveChanges();
            return RedirectToAction("List_The_Locations");
        }
        
        public ActionResult Edit(int? id)
        {
            Location location = db.Locations.Find(id);
            return View(location);
        }
        [HttpPost]
        public ActionResult Edit(Location location)
        {
            Location updated_location = db.Locations.Where(x => x.LocationID == location.LocationID).FirstOrDefault();
            Location exist_location = db.Locations.FirstOrDefault(x=>x.locationName==location.locationName);
            List<MeetingRoom> meetingRooms = db.MeetingRooms.Where(x => x.LocationID == location.LocationID).ToList();//bu lokasyondaki toplantilar liste halinde cekildi
            if (location.locationName!= null)
            {
                foreach (var item in meetingRooms)
                {
                    List<Meeting> meetings = db.Meetings.Where(x => x.MeetingRoomID == item.MeetingRoomID).ToList();
                    //bu toplanti odasindaki toplantilar bir listeye cekildi
                    //eger daha once bu toplanti ile ilgili bildirim gonderildiyse
                    //bu bildirimin mesajini guncellemeliyiz
                    foreach (var item1 in meetings)
                    {
                        Notification notification = db.Notifications.Where(x => x.MeetingID == item1.MeetingID).FirstOrDefault();
                        if (notification != null && item1.end_of_meeting.CompareTo(DateTime.Now) >= 0)//eger bu toplanti ile ilgili bir bildirim gonderilmissse bu bildirimin mesajı degistirilmeli
                        {
                            List<UserAndMeeting> userAndMeetings = db.UserAndMeetings.Where(x => x.MeetingID == item1.MeetingID).ToList();
                            //toplantiya katilacak olanlari bulmamiz lazim,cunku guncelleme bildirimi onlara gonderilecek
                            //bu kisilere onceden bildirim gonderildi,ancak aralarindan bazilari bildirimi silmis olabilir
                            //bu durumda tekrardan bildirim gonderilmeli
                            foreach (var item2 in userAndMeetings)
                            {
                                if (db.UserAndNotifications.Where(x => x.userID == item2.UserID).Where(y => y.NotificationID == notification.NotificationID).FirstOrDefault() == null)
                                {
                                    //eger katilimcilardan biri gelen bildirimini sildiyse yeni bildirim gonderilmeli
                                    UserAndNotification userAndNotification = new UserAndNotification();
                                    userAndNotification.NotificationID = notification.NotificationID;
                                    userAndNotification.userID = item2.UserID;
                                    db.UserAndNotifications.Add(userAndNotification);
                                    db.SaveChanges();
                                }
                            }
                            String intro = "Location is " + location.locationName + " and Room is " + item.RoomName;
                            String date = "Beginning Time: " + item1.beginning_of_meeting +
                                " Ending Time: " + item1.end_of_meeting;
                            notification.Message = intro + " " + date;
                            notification.TimeOfSentIt = DateTime.Now;
                        }
                    }
                }
                if ((updated_location.locationName != location.locationName && exist_location == null) || location.locationName == updated_location.locationName)
                {
                    //aynı lokasyon adına sahip baska bir lokasyon var mi diye bakiyoruz,eger varsa tekrar lokasyon adı girmesi istenir
                    updated_location.locationName = location.locationName;
                    db.SaveChanges();
                    return RedirectToAction("List_The_Locations");
                }
                ViewBag.message = "There is the location with the same name!!!";
            }
            else
            {
                ViewBag.message = "Please enter the Location Name!!!";
            }
            return View("Edit",location);
        }

    }
}