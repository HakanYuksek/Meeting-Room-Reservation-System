﻿using MeetingRoomReservation.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace MeetingRoomReservation.Controllers
{
    [Authorize]
    public class MyAccountController : Controller
    {
        MeetingDBContext db = new MeetingDBContext();
        // GET: MyAccount
        public ActionResult ShowMyProfile()
        {
            User myUser = db.Users.FirstOrDefault(x => x.Username == User.Identity.Name);
            return View(myUser);
        }
        public ActionResult Edit(int? id)
        {
            User myUser = db.Users.Find(id);
            return View(myUser);
        }

        [HttpPost]
        public ActionResult Edit(User user)
        {
            User updated_user = db.Users.Where(x => x.UserID == user.UserID).FirstOrDefault();//bilgileri guncellenmek istenen kullanicinin eski bilgilerini tutar
            User exist_user = db.Users.FirstOrDefault(x => x.Username == user.Username);
            if (user.Username != null && user.Password != null && user.Fullname != null && user.Email != null)
            {
                //degistirilmek istenen kullanici adinin baska bir kullaniciya ait olup olmadigini kontrol etmemiz gerekiyor...
                if ((updated_user.Username != user.Username && exist_user == null) || updated_user.Username == user.Username)
                {
                    if ((updated_user.Email != user.Email && db.Users.FirstOrDefault(x => x.Email == user.Email) == null) || updated_user.Email == user.Email)
                    {
                        //girilen yeni degerler gecerli ise bu kullanici veri tabanında guncellenir
                        updated_user.Username = user.Username;
                        updated_user.Password = user.Password;
                        updated_user.Fullname = user.Fullname;
                        updated_user.Email = user.Email;
                        FormsAuthentication.SetAuthCookie(updated_user.Username, false);
                        db.SaveChanges();
                        //kullanicinin verileri guncellendi...
                        return RedirectToAction("ShowMyProfile");
                    }
                    else
                    {
                        ViewBag.message = "There is an user with the same E-Mail address!!!";
                        return View("Edit", user);
                    }
                }
                else
                {
                    ViewBag.message = "There is an user with the same Username!!!";
                    return View("Edit", user);
                }
            }
            ViewBag.message = "Empty Field,Please fill the all blanks!!!";
            return View("Edit", user);
        }
    }
}