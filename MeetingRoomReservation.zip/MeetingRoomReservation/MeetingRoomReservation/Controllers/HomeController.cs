﻿using MeetingRoomReservation.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace MeetingRoomReservation.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
       MeetingDBContext db = new MeetingDBContext();
       [HttpGet]
       public ActionResult Index(LoginModel model)
        {
            return View(model);
        }
        public ActionResult ChooseLocation()
        {
            List<Location> locations = db.Locations.ToList();
            return View(locations);
        }
        public ActionResult ListTheMeetingRooms(String LocationName)
        {
            Location location = db.Locations.FirstOrDefault(x=>x.locationName==LocationName);
            List<MeetingRoom> meetingRooms = db.MeetingRooms.Where(x => x.LocationID == location.LocationID).ToList();
            return View(meetingRooms);
        }
        public ActionResult MeetingRoomDetails(int? id)
        {
            MeetingRoom meetingRoom = db.MeetingRooms.Find(id);            
            return View(meetingRoom);
        }
        [HttpPost]
        public ActionResult ShowMeetingRoomDetails(MeetingRoom meetingRoom,DateTime date)
        {
            meetingRoom = db.MeetingRooms.Find(meetingRoom.MeetingRoomID);
            meetingRoom.Location = db.Locations.Find(meetingRoom.LocationID);
            List<Meeting> meetings = db.Meetings.Where(x => x.MeetingRoomID == meetingRoom.MeetingRoomID).ToList();
            List<Meeting> meetingsInToday = new List<Meeting>();
            foreach(var item in meetings)
            {
                if (item.beginning_of_meeting.DayOfYear == date.DayOfYear)
                {
                    meetingsInToday.Add(item);
                }
            }
            //secilen tarihteki,bu toplanti odasinda rezervasyonu yapilmis toplantilar listelenir
            meetingsInToday = SortMeetings(meetingsInToday);//toplanti baslangic tarihlerine gore siraladik
            ViewBag.room = meetingRoom;
            ViewBag.id = meetingRoom.MeetingRoomID;
            TempData["date"] = date.ToString("dd-MM-yyyy");
            return View(meetingsInToday);
        }
        public List<Meeting> SortMeetings(List<Meeting>meetings)
        {
            //secilen gün icerisindeki toplantılar,baslama zamanlarina gore selection sort algoritması ile siralaniyor...
            DateTime min;
            Meeting tmp;
            int k;
            Meeting[] meetingsInToday = meetings.ToArray();
            for(int i = 0; i < meetingsInToday.Length-1; i++)
            {
                k = i;
                min = meetingsInToday[i].beginning_of_meeting;
                for(int j = i + 1; j < meetingsInToday.Length; j++)
                {
                    if (min.CompareTo(meetingsInToday[j].beginning_of_meeting) > 0)
                    {
                        min = meetingsInToday[j].beginning_of_meeting;
                        k = j;
                    }
                }
                tmp = meetingsInToday[i];
                meetingsInToday[i] = meetingsInToday[k];
                meetingsInToday[k] = tmp;
            }
            return meetingsInToday.ToList();
        }
        //ShowMyPlan metodu kullanıcının gün icerisinde katilacagi toplantilari listeler
        public ActionResult ShowMyPlan()
        {
            User user = db.Users.FirstOrDefault(x => x.Username == User.Identity.Name);
            List<UserAndMeeting> userAndMeetings = db.UserAndMeetings.Where(x => x.UserID == user.UserID).ToList();
            List<Meeting> meetings = new List<Meeting>();
            foreach (var item in userAndMeetings) {
                Meeting meeting = db.Meetings.Find(item.MeetingID);
                if (meeting.beginning_of_meeting.DayOfYear == DateTime.Now.DayOfYear)
                {
                    MeetingRoom meetingRoom = db.MeetingRooms.Find(meeting.MeetingRoomID);
                    Location location = db.Locations.Find(meetingRoom.LocationID);
                    meetingRoom.Location = location;
                    meeting.meetingRoom = meetingRoom;
                    meetings.Add(meeting);
                }
            }
            meetings = SortMeetings(meetings);
            return View(meetings);
        }
        public ActionResult ShowNotification()
        {
            User user = db.Users.FirstOrDefault(x=>x.Username==User.Identity.Name);
            List<UserAndNotification> userAndNotifications=db.UserAndNotifications.Where(x=>x.userID==user.UserID).ToList();
            List<Notification> notifications = new List<Notification>();
            foreach(var item in userAndNotifications)
            {
                Notification notification = db.Notifications.Find(item.NotificationID);
                notifications.Add(notification);
            }
            return View(notifications);
        }
        public ActionResult DeleteNotification(int? id)
        {
            //MyNotifications sayfasindan silmeyi saglamak amaciyla yazildi
            User user = db.Users.FirstOrDefault(x => x.Username == User.Identity.Name);
            UserAndNotification notification = db.UserAndNotifications.Where(x => x.userID == user.UserID).Where(y => y.NotificationID == id).FirstOrDefault();
            db.UserAndNotifications.Remove(notification);
            db.SaveChanges();
            return RedirectToAction("ShowNotification");
        }
        public ActionResult DeleteNotificationWithQuick(int? id)
        {
            //headBar kismindan bildirim silmeyi saglamak amaciyla yazildi
            User user = db.Users.FirstOrDefault(x => x.Username == User.Identity.Name);
            UserAndNotification notification = db.UserAndNotifications.Where(x => x.userID == user.UserID).Where(y => y.NotificationID == id).FirstOrDefault();
            db.UserAndNotifications.Remove(notification);
            db.SaveChanges();
            return Redirect(Request.UrlReferrer.ToString());
        }
        public ActionResult ShowDetailsOfRoom(int? id)
        {
            //mevcut toplanti rezervasyonunun detaylari gosterilir...
            Meeting meeting = db.Meetings.Find(id);
            List<UserAndMeeting> userAndMeetings = db.UserAndMeetings.Where(x => x.MeetingID == id).ToList();
            List<User> userList = new List<User>();
            MeetingRoom meetingRoom = db.MeetingRooms.Find(meeting.MeetingRoomID);
            ViewData["locationName"] = db.Locations.Find(meetingRoom.LocationID).locationName;
            foreach (var item in userAndMeetings)
            {
                User user = db.Users.Find(item.UserID);
                userList.Add(user);
            }
            ViewBag.List = userList;
            return View(meeting);
        }
    }
}