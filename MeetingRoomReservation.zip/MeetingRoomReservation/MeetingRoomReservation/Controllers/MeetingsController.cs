﻿using MeetingRoomReservation.Authentication;
using MeetingRoomReservation.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MeetingRoomReservation.Controllers
{
    [_SessionControl]
    public class MeetingsController : Controller
    {
        MeetingDBContext db = new MeetingDBContext();
        // GET: Meeting
        public ActionResult Index()
        {
            List<Meeting> meetings = db.Meetings.ToList();
            HomeController homeController = new HomeController();
            //homeController nesnesini mevcut tum toplantilari baslangic tarihlerine gore siralamak icin kullandim
            meetings = homeController.SortMeetings(meetings);
            ViewBag.Locations = db.Locations.ToList();
            return View(meetings);
        }
        public ActionResult Delete(int? id)
        {
            Meeting meeting = db.Meetings.Find(id);
            List<UserAndMeeting> users_meetings = db.UserAndMeetings.Where(x=>x.MeetingID==id).ToList();
            Notification notification = db.Notifications.Where(x => x.MeetingID == id).FirstOrDefault();
            if (notification != null && meeting.end_of_meeting.CompareTo(DateTime.Now)>=0)
            {
                List<UserAndNotification> userAndNotifications = db.UserAndNotifications.Where(x => x.NotificationID == notification.NotificationID).ToList();
                foreach (var item in users_meetings)
                {
                    //eger kullanici bu toplanti iptal edilmeden once bu bildirimi silerse,toplanti iptal edildi diye bir bildirim daha gonderilmeli
                    if (db.UserAndNotifications.Where(x => x.userID == item.UserID).Where(y => y.NotificationID == notification.NotificationID).FirstOrDefault() == null)
                    {
                        UserAndNotification temp = new UserAndNotification();
                        temp.NotificationID = notification.NotificationID;
                        temp.userID = item.UserID;
                        db.UserAndNotifications.Add(temp);
                        db.SaveChanges();
                    }
                }
                notification.Message = "The Meeting where is in " + meeting.meetingRoom.Location.locationName + "  " + meeting.meetingRoom.RoomName +
                               "  is cancelled!!!";
                notification.TimeOfSentIt = DateTime.Now;
            }
            db.UserAndMeetings.RemoveRange(users_meetings);
            db.Meetings.Remove(meeting);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult Details(int? id)
        {
            Meeting meeting = db.Meetings.Find(id);
            List<UserAndMeeting> userAndMeetings = db.UserAndMeetings.Where(x=>x.MeetingID==id).ToList();
            List<User> userList = new List<User>();
            MeetingRoom meetingRoom = db.MeetingRooms.Find(meeting.MeetingRoomID);
            ViewData["locationName"] = db.Locations.Find(meetingRoom.LocationID).locationName;
            foreach (var item in userAndMeetings)
            {
                User user = db.Users.Find(item.UserID);
                userList.Add(user);
            }
            ViewBag.List = userList;
            return View(meeting);
        }
        [HttpPost]
        public ActionResult Filter(String locationName, String start_date)
        {
            List<Meeting> meetings = db.Meetings.ToList();
            List<Meeting> myMeetings = new List<Meeting>();
            Boolean isFiltered = false;
            ViewBag.Locations = db.Locations.ToList();
            if (locationName !="Select Location" && start_date!="") {
                Location location = db.Locations.FirstOrDefault(x => x.locationName == locationName);
                DateTime time = Convert.ToDateTime(start_date);
                foreach (var item in meetings)
                {
                    MeetingRoom meetingRoom = db.MeetingRooms.Find(item.MeetingRoomID);
                    if (item.beginning_of_meeting.DayOfYear==time.DayOfYear && item.meetingRoom.LocationID == location.LocationID)
                    {
                        myMeetings.Add(item);
                    }
                }
                isFiltered = true;
            }else if (locationName!="Select Location")
            {
                Location location = db.Locations.FirstOrDefault(x => x.locationName == locationName);
                foreach (var item in meetings)
                {
                    MeetingRoom meetingRoom = db.MeetingRooms.Find(item.MeetingRoomID);
                    if (item.meetingRoom.LocationID == location.LocationID)
                    {
                        myMeetings.Add(item);
                    }
                }
                isFiltered = true;
            }else if (start_date!="")
            {
                DateTime time = Convert.ToDateTime(start_date);
                foreach(var item in meetings)
                {
                    if (item.beginning_of_meeting.DayOfYear == time.DayOfYear)
                    {
                        myMeetings.Add(item);
                    }
                }
                isFiltered = true;
            }
            if (isFiltered)
            {
                HomeController homeController = new HomeController();
                myMeetings = homeController.SortMeetings(myMeetings);
                return View("Index", myMeetings);
            }
            else
            {
                return RedirectToAction("Index");
            }
           
        }
    }
}