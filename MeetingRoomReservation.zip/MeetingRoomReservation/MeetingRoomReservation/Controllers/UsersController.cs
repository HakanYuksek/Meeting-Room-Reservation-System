﻿using MeetingRoomReservation.Authentication;
using MeetingRoomReservation.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MeetingRoomReservation.Controllers
{
    
    //alttaki attribute kullanicinin rolünün admin olup olmadigina bakiyor,eger admin degilse ana sayfaya yonlendiriyor
    [_SessionControl]
    public class UsersController : Controller
    {
        MeetingDBContext db = new MeetingDBContext();
        
        public ActionResult List_The_Users()
        {
            //veri tabanındaki kullanıcılar listelenir
            List<User> userlist = db.Users.ToList();
            return View(userlist);
        }

        public ActionResult Add_New_User()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Add_New_User(User user)
        {
            if (db.Users.FirstOrDefault(x => x.Username == user.Username)==null) {//bu kullanici adına sahip baska biri olmamali
                if (db.Users.FirstOrDefault(x => x.Email == user.Email) == null)//bu mail adresine sahip baska kullanici olmamali
                {
                    if (user.Username != null && user.Password != null && user.Email != null && user.role != "Select Role" && user.Fullname != null)
                    {//girilmesi gereken degerlerin girilip girilmediği kontrol edilir
                        db.Users.Add(user);
                        db.SaveChanges();
                        return RedirectToAction("List_The_Users");
                    }
                    else
                    {
                        ViewBag.message = "Empty Field";
                        return View("Add_New_User");
                    }
                }
                else
                {
                    ViewBag.message = "Somebody has already had this E-Mail address!!!";
                    return View("Add_New_User");
                }
            }
            else
            {
                ViewBag.message = "somebody has already had this username!!!";
                return View("Add_New_User");
            }
        }
       
        public ActionResult Delete(int? id)//kayitli kullanicilari silmeye yarayan metot
        {
            var user = db.Users.FirstOrDefault(x => x.UserID == id);
            //kullanicinin katilacagi toplantilarin katilacaklar listesinden bu kullanici silinmelidir
            List<UserAndMeeting> userAndMeetings = db.UserAndMeetings.Where(x => x.UserID == id).ToList();
            db.UserAndMeetings.RemoveRange(userAndMeetings);
            //bu kullaniciya gonderilmis bildirimler de silinmelidir
            List<UserAndNotification> userAndNotifications = db.UserAndNotifications.Where(x => x.userID == id).ToList();
            db.UserAndNotifications.RemoveRange(userAndNotifications);
            //daha sonra kullanici veri tabaninda silinir
            db.Users.Remove(user);
            db.SaveChanges();
            return RedirectToAction("List_The_Users");
        }

        public ActionResult Edit(int? id)
        {
            var user = db.Users.Find(id);
            return View(user);
        }

        [HttpPost]
        public ActionResult Edit(User user)
        {
            User updated_user = db.Users.Where(x => x.UserID == user.UserID).FirstOrDefault();//guncellenecek olan kullanicinin eski bilgileri
            User exist_user = db.Users.FirstOrDefault(x => x.Username == user.Username);//ayni kullanici adina sahip baska biri var mi
            //degistirilmek istenen kullanici adinin baska bir kullaniciya ait olup olmadigini kontrol etmemiz gerekiyor...
            if (user.role!="Select Role")
            {
                if (user.Username != null)
                {
                    if (user.Password != null)
                    {
                        if (user.Fullname != null)
                        {
                            if (user.Email != null)
                            {
                                if ((updated_user.Username != user.Username && exist_user == null) || updated_user.Username == user.Username)
                                {
                                    if ((updated_user.Email!=user.Email && db.Users.FirstOrDefault(x=>x.Email==user.Email)==null) || updated_user.Email==user.Email) {
                                        //girilen yeni degerler gecerli ise bu kullanici veri tabanında guncellenir
                                        updated_user.Username = user.Username;
                                        updated_user.role = user.role;
                                        updated_user.Password = user.Password;
                                        updated_user.Fullname = user.Fullname;
                                        updated_user.Email = user.Email;
                                        db.SaveChanges();
                                        //kullanicinin verileri guncellendi...
                                        return RedirectToAction("List_The_Users");
                                    }
                                    else
                                    {
                                        ViewBag.message = "Somebody has already had this E-Mail address!!!";
                                    }
                                }
                                else
                                {
                                    ViewBag.message = "There is a user with the same name!!!";
                                }
                            }
                            else
                            {
                                ViewBag.message = "Please enter mail address!!!";
                            }
                        }
                        else
                        {
                            ViewBag.message="Please enter the Fullname!!!";
                        }
                    }
                    else
                    {
                        ViewBag.message = "Please enter the password!!!";
                    }
                }
                else
                {
                    ViewBag.message = "Please enter the username";
                }
            }
            else
            {
                ViewBag.message = "Please choose the role of the users!!!";
            }
            return View("Edit",user);
        }

        public ActionResult Change_Role(int? id)
        {
            /*
             Kullanicilar listesinde kullanıcıların statulerinin uzerine tıklandıgında bu bolume gelir
             eger kullanıcının yetkisi admin ise normal, normal ise de admin olarak degistirilir
            */
            User user = db.Users.Where(x => x.UserID == id).FirstOrDefault();
            if (user.role == "Admin")
            {
                user.role = "Normal";
            }
            else
            {
                user.role = "Admin";
            }
            db.SaveChanges();
            return RedirectToAction("List_The_Users");
        }

    }
}