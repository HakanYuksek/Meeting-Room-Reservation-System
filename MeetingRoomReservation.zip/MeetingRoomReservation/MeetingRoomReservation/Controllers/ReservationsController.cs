﻿using MeetingRoomReservation.Authentication;
using MeetingRoomReservation.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MeetingRoomReservation.Controllers
{
    [Authorize]
    public class ReservationsController : Controller
    {
        MeetingDBContext db = new MeetingDBContext();
        [_Approved]
        public ActionResult Choose_Location()
        {
            List<Location> locations = db.Locations.ToList();
            return View(locations);
        }
        [_Approved]
        public ActionResult ListTheMeetingRooms(String LocationName)
        {
            Location location = db.Locations.FirstOrDefault(x => x.locationName == LocationName);
            List<MeetingRoom> meetingRooms = db.MeetingRooms.Where(x => x.LocationID == location.LocationID).ToList();
            //secilen lokasyon icerisindeki butun toplantı odalarinin bulundugu liste, kullanicinin toplanti odasi secmesi icin gonderilir
            return View(meetingRooms);
        }
        [_Approved]
        public ActionResult Make_Reservation(int? id)
        {
            //kullanicinin sectigi toplanti odasinin id sinden, toplanti odasi bulunur
            MeetingRoom meetingRoom = db.MeetingRooms.Find(id);
            List<User> userList = db.Users.ToList();
            ViewBag.list = userList;//kullanicinin toplantiya katilacak olan kisileri secebilmesi icin kullanicilar listelenir
            return View(meetingRoom);
        }
        [_Approved]
        [HttpPost]
        public ActionResult Make_Reservation(MeetingRoom meetingRoom,String start_date,String start_time,String end_date,String end_time,String [] UserList)
        {
            Meeting meeting = new Meeting();
            meeting.beginning_of_meeting = Convert.ToDateTime(start_date + " " + start_time); ;
            meeting.end_of_meeting = Convert.ToDateTime(end_date + " " + end_time); ;
            //toplantının baslangıc ve bitis saatini aldık
            meetingRoom = db.MeetingRooms.Find(meetingRoom.MeetingRoomID);
            //secilen toplanti odasi, istenilen saatlerde uygun mu diye kontrol etmeliyiz...
            if (isSuitable(meetingRoom.MeetingRoomID, meeting.beginning_of_meeting, meeting.end_of_meeting))
            {
                if (UserList != null)//toplantıya katılan mutlaka kisiler olmalı
                {
                    if (UserList.Length <= meetingRoom.capacity)//toplantiya katilan kisilerin sayisi toplanti odasinin kapasitesinden az olmali
                    {
                        /*
                         toplantinin bitis tarihi baslama tarihinden once olamaz
                         ayni zamanda toplantinin baslangic tarihi, suan ki tarihten once de olamaz...
                         */
                        if (meeting.beginning_of_meeting.CompareTo(meeting.end_of_meeting) < 0 && meeting.beginning_of_meeting.CompareTo(DateTime.Now)>=0)
                        {
                            meeting.MeetingRoomID = meetingRoom.MeetingRoomID;
                            meeting.meetingRoom = meetingRoom;
                            meeting.OwnerID = db.Users.FirstOrDefault(x => x.Username == User.Identity.Name).UserID;
                            db.Meetings.Add(meeting);
                            db.SaveChanges();
                            foreach (var item in UserList)
                            {
                                User user = db.Users.FirstOrDefault(x => x.Username == item);
                                UserAndMeeting user_meeting = new UserAndMeeting();
                                user_meeting.UserID = user.UserID;
                                user_meeting.MeetingID = meeting.MeetingID;
                                db.UserAndMeetings.Add(user_meeting);
                            }
                            db.SaveChanges();
                            TempData["Message"] = "Your Reservation is confirmed, you can see the your reservations in the section of MyReservations";
                            return RedirectToAction("Index", "Home");
                        }
                        else
                        {
                            ViewData["message"] = "invalid dates!!!";
                        }
                    }
                    else
                    {
                        ViewData["message"] = "capacity of the room is not enough!!!";
                    }
                }
                else
                {
                    ViewData["message"] = "please choose the participants of meeting!!!";
                }
            }
            else
            {
                ViewData["message"] = "Sorry, there are already a meeting in this room!!!";
            }
            ViewBag.list = db.Users.ToList();
            return View("Make_Reservation", meetingRoom);
        }
        //asagidaki metot rezerve edilmek istenen odanin girilen saat araliklarinda rezervasyona uygun olup olmadigini arastirir
        public Boolean isSuitable(int meetingRoomID, DateTime beginning_of_meeting, DateTime end_of_meeting)
        {
            Boolean isSuitable = true; ;
            List<Meeting> meetings = db.Meetings.Where(x => x.MeetingRoomID == meetingRoomID).ToList();
            foreach(var item in meetings)
            {
                //mevcut toplantinin bitis tarihi, yeni toplantinin baslangic tarihinden once olabilir veya
                //mevcuut toplantinin baslangic tarihi, yeni toplantinin bitis tarihinden sonra olabilir
                if (!(item.end_of_meeting.CompareTo(beginning_of_meeting)<=0 || item.beginning_of_meeting.CompareTo(end_of_meeting)>=0))
                {
                    isSuitable = false;//eger secilen saatler icerisinde mevcut bir toplanti varsa geriye false dondurulur
                }
            }
            return isSuitable;
        }
        //kullanicinin icinde bulundugu toplanti rezervasyonlari listelenir
        public ActionResult ListMyReservations()
        {
            User user = db.Users.FirstOrDefault(x => x.Username == User.Identity.Name);
            List<UserAndMeeting> userAndMeetings = db.UserAndMeetings.Where(x => x.UserID == user.UserID).ToList();
            List<Meeting> meetings = new List<Meeting>();
            foreach (var item in userAndMeetings)
            {
                Meeting meeting = db.Meetings.Find(item.MeetingID);
                MeetingRoom meetingRoom = db.MeetingRooms.Find(meeting.MeetingRoomID);
                Location location = db.Locations.Find(meetingRoom.LocationID);
                meetingRoom.Location = location;
                meeting.meetingRoom = meetingRoom;
                meetings.Add(meeting);
            }
            /*
             *       Kullanici, olusturdugu toplanti odasi rezervasyonu icerisinde kendi olmayabilir
             *       ancak yine de bu toplanti rezervasyonunu iptal etme ve güncelleme 
             *       haklarina sahiptir,
             *       bu sebeple bu toplanti rezervasyonu da MyReservations listesinde bulunmalidir...
             * */
            List< Meeting> allMeetings = db.Meetings.ToList();
            foreach(var item in allMeetings)
            {
                if (meetings.FirstOrDefault(x=>x.MeetingID==item.MeetingID)==null && item.OwnerID==user.UserID)
                {
                    meetings.Add(item);
                }
            }
            //kullanicinin katilacagi rezervasyonlar, toplanti baslangic tarihlerine gore siralaniyorlar
            HomeController homeController = new HomeController();
            meetings=homeController.SortMeetings(meetings);
            //siralama icin ise daha once HomeControllerda yazmıs oldugum SortMeetings metodunu kullandim...
            ViewBag.User = db.Users.FirstOrDefault(x=>x.Username==User.Identity.Name);
            ViewBag.Locations = db.Locations.ToList();
            return View(meetings);
        }
        public ActionResult ShowDetails(int? id)
        {
            //mevcut toplanti rezervasyonunun detaylari gosterilir...
            Meeting meeting = db.Meetings.Find(id);
            if (meeting != null)
            {
                List<UserAndMeeting> userAndMeetings = db.UserAndMeetings.Where(x => x.MeetingID == id).ToList();
                List<User> userList = new List<User>();
                MeetingRoom meetingRoom = db.MeetingRooms.Find(meeting.MeetingRoomID);
                ViewData["locationName"] = db.Locations.Find(meetingRoom.LocationID).locationName;
                foreach (var item in userAndMeetings)
                {
                    User user = db.Users.Find(item.UserID);
                    userList.Add(user);
                }
                ViewBag.List = userList;
                return View("Details", meeting);
            }
            return RedirectToAction("ListMyReservations");
        }
        public ActionResult Delete(int? id)
        {
            Meeting meeting = db.Meetings.Find(id);
            meeting.meetingRoom = db.MeetingRooms.Find(meeting.MeetingRoomID);
            meeting.meetingRoom.Location = db.Locations.Find(meeting.meetingRoom.LocationID);
            User ownerOfMeeting = db.Users.FirstOrDefault(x => x.UserID == meeting.OwnerID);//toplantiyi olusturan kisi
            User user = db.Users.FirstOrDefault(x => x.Username == User.Identity.Name);//suan toplantiyi silmeye calisan kisi
            //bir toplantiyi ancak toplantiyi olusturan kisiler veya admin yetkisine sahip kisiler silebilir
            //ancak toplantiya katilan kisilerden biri rezervasyonu silmeye calisirsa sadece kendisini toplantiya katilanlar listesinden silebilir
            if(ownerOfMeeting.UserID==user.UserID || User.IsInRole("Admin"))
            {
                List<UserAndMeeting> users_meetings = db.UserAndMeetings.Where(x => x.MeetingID == id).ToList();
                Notification notification = db.Notifications.Where(x => x.MeetingID == meeting.MeetingID).FirstOrDefault();
                if (notification != null && meeting.end_of_meeting.CompareTo(DateTime.Now)>=0)
                {
                    List<UserAndNotification> userAndNotifications = db.UserAndNotifications.Where(x => x.NotificationID == notification.NotificationID).ToList();
                    foreach(var item in users_meetings)
                    {
                        //eger kullanici bu toplanti iptal edilmeden once bu bildirimi silerse,toplanti iptal edildi diye bir bildirim daha gonderilmeli
                        if (db.UserAndNotifications.Where(x=>x.userID==item.UserID).Where(y=>y.NotificationID==notification.NotificationID).FirstOrDefault()==null)
                        {
                            UserAndNotification temp = new UserAndNotification();
                            temp.NotificationID = notification.NotificationID;
                            temp.userID = item.UserID;
                            db.UserAndNotifications.Add(temp);
                            db.SaveChanges();
                        }
                    }
                    notification.Message = "The Meeting where is in "+meeting.meetingRoom.Location.locationName+"  "+meeting.meetingRoom.RoomName+
                        "  is cancelled!!!";
                    notification.TimeOfSentIt = DateTime.Now;
                }
                db.UserAndMeetings.RemoveRange(users_meetings);
                db.Meetings.Remove(meeting);
                db.SaveChanges();
            }
            else
            {
                //kullanici bu toplanti iptali icin gerekli izinlere sahip degilse, sadece kendisini bu toplantıya katılanlar listesinden silebilir
                UserAndMeeting users_meetings = db.UserAndMeetings.Where(x => x.MeetingID == id).Where(y=>y.UserID==user.UserID).FirstOrDefault();
                db.UserAndMeetings.Remove(users_meetings);
                Notification notification = db.Notifications.Where(x => x.MeetingID == id).FirstOrDefault();
                UserAndNotification myNotification = db.UserAndNotifications.Where(x => x.NotificationID == notification.NotificationID).Where(y => y.userID == user.UserID).FirstOrDefault();
                if (notification != null && meeting.end_of_meeting.CompareTo(DateTime.Now)>=0)
                {
                    //eger bu toplanti ile ilgili bildirim kullaniciya yollanmissa ve kullanici bu toplantiya katilmayacaksa
                    //kullaniciya daha once gonderilmis olan bildirim mesajinda kullanicinin toplanti katilimcilari arasindan ayrildigi belirtilir
                    db.UserAndNotifications.Remove(myNotification);
                    Notification leftFromNotification = new Notification();
                    leftFromNotification.MeetingID = meeting.MeetingID;
                    leftFromNotification.TimeOfSentIt = DateTime.Now;
                    leftFromNotification.Message = "You left from the participants of this meeting!!!";
                    db.Notifications.Add(leftFromNotification);
                    db.SaveChanges();
                    UserAndNotification deleteMessage = new UserAndNotification();
                    deleteMessage.NotificationID = leftFromNotification.NotificationID;
                    deleteMessage.userID = user.UserID;
                    db.UserAndNotifications.Add(deleteMessage);
                    db.SaveChanges();
                }
                db.SaveChanges();
            }
            return RedirectToAction("ListMyReservations");
        }
        public ActionResult Edit(int? id)
        {
            Meeting meeting = db.Meetings.Find(id);
            meeting.meetingRoom = db.MeetingRooms.Find(meeting.MeetingRoomID);
            List<UserAndMeeting> userAndMeeting = db.UserAndMeetings.Where(x => x.MeetingID == meeting.MeetingID).ToList();
            List<User> users = new List<User>();
            foreach(var item in userAndMeeting)
            {
                users.Add(db.Users.Where(x => x.UserID == item.UserID).FirstOrDefault());
            }
            ViewBag.List = users;
            ViewBag.Allusers = db.Users.ToList();
            return View(meeting);
        }

        [HttpPost]
        public ActionResult Edit(Meeting meeting,MeetingRoom meetingRoom,int OwnerID,String start_date, String start_time, String end_date, String end_time, String[] UserList)
        {
            User owner = db.Users.Find(OwnerID);
            meeting = db.Meetings.Where(x => x.MeetingID == meeting.MeetingID).FirstOrDefault();
            meetingRoom = db.MeetingRooms.Find(meetingRoom.MeetingRoomID);
            Location location = db.Locations.Find(meetingRoom.LocationID);
            meeting.beginning_of_meeting = Convert.ToDateTime(start_date + " " + start_time);
            meeting.end_of_meeting = Convert.ToDateTime(end_date + " " + end_time);
            List<UserAndMeeting> userAndMeeting = db.UserAndMeetings.Where(x => x.MeetingID == meeting.MeetingID).ToList();
            List<User> users = new List<User>();
            foreach (var item in userAndMeeting)
            {
                users.Add(db.Users.Where(x => x.UserID == item.UserID).FirstOrDefault());//toplantiya katilacak olan kisiler bulundu
            }
            ViewBag.List = users;
            ViewBag.Allusers = db.Users.ToList();
            //kullanicinin degisiklik yapma yetkisinin olup olmadigini kontrol ediyoruz
            if (owner.Username == User.Identity.Name || User.IsInRole("Admin"))
            {    
                //secilen toplanti odasi, istenilen saatlerde uygun mu diye kontrol etmeliyiz...
              //ancak kullanici belki saati degistirmemis olabilir
                if (isSuitable(meetingRoom.MeetingRoomID, Convert.ToDateTime(start_date + " " + start_time), Convert.ToDateTime(end_date + " " + end_time))
                    || ((meeting.beginning_of_meeting.CompareTo(Convert.ToDateTime(start_date + " " + start_time))) == 0
                    && (meeting.end_of_meeting.CompareTo(Convert.ToDateTime(end_date + " " + end_time))) == 0))
                {
                    if (UserList != null)//mutlaka toplantiya birileri katilmali...
                    {
                        if (UserList.Length <= meetingRoom.capacity)//toplantiya katilacak kisilerin sayisi,toplanti odasinin kapasitesinden fazla olamaz
                        {
                            if (Convert.ToDateTime(start_date + " " + start_time).CompareTo(Convert.ToDateTime(end_date + " " + end_time)) < 0 && Convert.ToDateTime(start_date + " " + start_time).CompareTo(DateTime.Now)>=0)
                            {           //toplantinin baslangic tarihi, bitis tarihinden once olamaz,ayrica gecmis tarihte secilememeli
                                List<UserAndMeeting> userAndmeetings = db.UserAndMeetings.Where(x => x.MeetingID == meeting.MeetingID).ToList();
                                db.UserAndMeetings.RemoveRange(userAndmeetings);
                                Notification notification = db.Notifications.Where(x => x.MeetingID == meeting.MeetingID).FirstOrDefault();
                                if (notification != null)
                                {
                                    List<UserAndNotification> deleteThem = db.UserAndNotifications.Where(x => x.NotificationID == notification.NotificationID).ToList();
                                    //once bu toplanti ile ilgili gonderilen bildirimler silinir daha sonrasinda ise bu bildirimler tekrar yollanir
                                    //cunku katilimci silinmis olabilir
                                    db.UserAndNotifications.RemoveRange(deleteThem);
                                }
                                db.SaveChanges();
                                List<User> newUserList = new List<User>();
                                foreach (var item in UserList)
                                {
                                    User user = db.Users.FirstOrDefault(x => x.Username == item);
                                    newUserList.Add(user);//yeni katilimcilar listesine ekledik
                                    UserAndMeeting user_meeting = new UserAndMeeting();
                                    user_meeting.UserID = user.UserID;
                                    user_meeting.MeetingID = meeting.MeetingID;
                                    db.UserAndMeetings.Add(user_meeting);
                                    //bildirim guncellemesi asagidan itibaren yapiliyor
                                    if (notification != null)//bu toplanti ile ilgili bildirim gonderildi mi diye kontrol edilir
                                    {
                                        String intro = "Location is " + location.locationName + " and Room is " + meetingRoom.RoomName;
                                        String date = "Beginning Time: " + meeting.beginning_of_meeting +
                                            " Ending Time: " + meeting.end_of_meeting;
                                        notification.Message = intro + " " + date;
                                        notification.TimeOfSentIt = DateTime.Now;
                                        UserAndNotification userAndNotification = new UserAndNotification();
                                        userAndNotification.userID = user.UserID;
                                        userAndNotification.NotificationID = notification.NotificationID;
                                        db.UserAndNotifications.Add(userAndNotification);
                                        db.SaveChanges();           
                                    }
                                }
                                db.SaveChanges();
                                //asagidaki kisimda toplanti katilimcilari arasindan cikarilmis olan kisilere gonderilecek bildirimin olusturulmasi yer aliyor
                                if (notification != null)//bu toplanti ile ilgili bildirim gonderilmisse bu islemler yapilmali
                                {
                                    if (users.Except(newUserList).ToList().Count != 0)
                                    {
                                        Notification oldNotif = new Notification();
                                        oldNotif.MeetingID = meeting.MeetingID;
                                        oldNotif.Message = "Location is  " + location.locationName + " and Room is " + meetingRoom.RoomName +
                                            "Beginning Time: " + meeting.beginning_of_meeting +
                                                    " Ending Time: " + meeting.end_of_meeting + "\n" +
                                        " you are removed from participants of this meeting";
                                        oldNotif.TimeOfSentIt = DateTime.Now;
                                        db.Notifications.Add(oldNotif);
                                        db.SaveChanges();
                                        //onceden bu toplantiya katilacak olup guncelleme sonrasi katilmayacak olan kullanicilara bildirim gonderilmeli
                                        foreach (var item in users)
                                        {
                                            if (!newUserList.Contains(item))
                                            {
                                                UserAndNotification userAndNotification = new UserAndNotification();
                                                userAndNotification.userID = item.UserID;
                                                userAndNotification.NotificationID = oldNotif.NotificationID;
                                                db.UserAndNotifications.Add(userAndNotification);
                                                db.SaveChanges();
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                ViewBag.message = "invalid Dates!!!";
                                return View("Edit", meeting);
                            }
                        }
                        else
                        {
                            ViewBag.message = "The capacity of the room is not enough!!!";
                            return View("Edit", meeting);
                        }
                    }
                    else
                    {
                        ViewBag.message = "Please choose the participants of meeting!!!";
                        return View("Edit", meeting);
                    }
                }
                else
                {
                    ViewBag.message = "There are already a meeting between these hours!!!";
                    return View("Edit", meeting);
                }
            }
            else
            {
                ViewBag.message = "You have no permissions to edit this meeting!!!";
                return View("Edit", meeting);
            }
            return RedirectToAction("ListMyReservations");
        }
        [HttpPost]
        public ActionResult Filter(String locationName,String start_date)
        {
            User user = db.Users.FirstOrDefault(x => x.Username == User.Identity.Name);
            List<UserAndMeeting> userAndMeetings = db.UserAndMeetings.Where(x => x.UserID == user.UserID).ToList();
            List<Meeting> myMeetings = new List<Meeting>();
            ViewBag.User = user;
            ViewBag.Locations = db.Locations.ToList();
            Boolean isFiltered = false;//bu degiskenin amaci kullanicinin herhangi bir filtreleme secenegini secip secmedigini kontrol etmek
            //eger secmediyse ListMyReservations metoduna gideriz, eger sectiyse yeni bir listemiz var demektir,bu listeyi View e gondeririz
            if (locationName != "Select Location" && start_date != "")
            {
                //bu kosulda kullanicinin sectigi lokasyon ve tarihe gore kullanici rezervasyonlari filtrelenir
                Location location = db.Locations.Where(x => x.locationName ==locationName).FirstOrDefault();
                foreach(var item in userAndMeetings)
                {
                    //bu for dongusu icerisinde kullanicinin katilacagi toplantilardan filtreleme kosullarina uyanlar bulunur
                    Meeting meeting = db.Meetings.Find(item.MeetingID);
                    MeetingRoom meetingRoom = db.MeetingRooms.Find(meeting.MeetingRoomID);
                    if (meetingRoom.LocationID == location.LocationID && meeting.beginning_of_meeting.DayOfYear==Convert.ToDateTime(start_date).DayOfYear)
                    {
                        meetingRoom.Location = location;
                        myMeetings.Add(meeting);
                    }
                }
                //alttaki for dongusu icerisinde kullanicinin olusturmus oldugu ancak katilmadigi toplantilar listeye kaydedilir
                foreach (var item in db.Meetings.ToList())
                {
                    Meeting meeting = db.Meetings.Find(item.MeetingID);
                    MeetingRoom meetingRoom = db.MeetingRooms.Find(meeting.MeetingRoomID);
                    if (!myMeetings.Contains(item) && item.OwnerID == user.UserID)
                    {
                        if (meetingRoom.LocationID == location.LocationID && meeting.beginning_of_meeting.DayOfYear == Convert.ToDateTime(start_date).DayOfYear)
                        {
                            meetingRoom.Location = location;
                            myMeetings.Add(meeting);
                        }
                    }
                }
                isFiltered = true;
            }else if (locationName!="Select Location")//bu kosulda ise kullanici sadece lokasyona gore filtrelemek istemis oluyor
            {
                Location location = db.Locations.Where(x => x.locationName == locationName).FirstOrDefault();
                foreach (var item in userAndMeetings)
                {
                    //bu for dongusu icerisinde kullanicinin katilacagi toplantilardan filtreleme kosullarina uyanlar bulunur
                    Meeting meeting = db.Meetings.Find(item.MeetingID);
                    MeetingRoom meetingRoom = db.MeetingRooms.Find(meeting.MeetingRoomID);
                    if (meetingRoom.LocationID == location.LocationID)
                    {
                        meetingRoom.Location = location;
                        myMeetings.Add(meeting);
                    }
                }
                //alttaki for dongusu icerisinde kullanicinin olusturmus oldugu ancak katilmadigi toplantilar listeye kaydedilir
                foreach (var item in db.Meetings.ToList())
                {
                    if (!myMeetings.Contains(item) && item.OwnerID == user.UserID)
                    {
                        Meeting meeting = db.Meetings.Find(item.MeetingID);
                        MeetingRoom meetingRoom = db.MeetingRooms.Find(meeting.MeetingRoomID);
                        if (meetingRoom.LocationID == location.LocationID)
                        {
                            meetingRoom.Location = location;
                            myMeetings.Add(meeting);
                        }
                    }
                }
                isFiltered = true;
            }
            else if (start_date != "")//bu kosulda ise kullanici sadece belirli bir tarihteki rezervasyonlarini goruntelemek istemis oluyor
            {
                foreach (var item in userAndMeetings)
                {
                    //bu for dongusu icerisinde kullanicinin katilacagi toplantilardan filtreleme kosullarina uyanlar bulunur
                    Meeting meeting = db.Meetings.Find(item.MeetingID);
                    MeetingRoom meetingRoom = db.MeetingRooms.Find(meeting.MeetingRoomID);
                    if (Convert.ToDateTime(start_date).DayOfYear==meeting.beginning_of_meeting.DayOfYear)
                    {
                        meetingRoom.Location = db.Locations.FirstOrDefault(x=>x.LocationID==meetingRoom.LocationID);
                        myMeetings.Add(meeting);
                    }
                }
                //alttaki for dongusu;  
                //kullanicinin olusturdugu ancak katilmayacagi toplantilari listeye eklemek icin kullanildi
                foreach (var item in db.Meetings.ToList())
                {
                    if (!myMeetings.Contains(item) && item.OwnerID == user.UserID)
                    {
                        Meeting meeting = db.Meetings.Find(item.MeetingID);
                        MeetingRoom meetingRoom = db.MeetingRooms.Find(meeting.MeetingRoomID);
                        if (Convert.ToDateTime(start_date).DayOfYear == meeting.beginning_of_meeting.DayOfYear)
                        {
                            meetingRoom.Location = db.Locations.FirstOrDefault(x => x.LocationID == meetingRoom.LocationID);
                            myMeetings.Add(meeting);
                        }
                    }
                }
                isFiltered = true;
            }
            if (isFiltered)//filtreleme yapildiysa isFiltered degiskeni true olur
            {
                HomeController homeController = new HomeController();
                //HomeController nesnesi olusturma sebebim; bu nesne icin daha once yazmis oldugum siralama metodunu tekrardan kullanmaktir
                myMeetings = homeController.SortMeetings(myMeetings);
                return View("ListMyReservations", myMeetings);
            }
            else
            {
                return RedirectToAction("ListMyReservations");
            }
        }
    }
}
