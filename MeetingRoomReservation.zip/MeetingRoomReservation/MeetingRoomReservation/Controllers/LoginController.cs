﻿using MeetingRoomReservation.Models;
using MeetingRoomReservation.Roles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace MeetingRoomReservation.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Sign_in(LoginModel model)
        {
            MeetingDBContext db = new MeetingDBContext();
            var user = db.Users.FirstOrDefault(x => x.Username == model.Username);//bu kullanici adina sahip biri var mı diye users tablosunda aranir
            if (user != null)//eger varsa, sifreyi dogru girip girmedigi kontrol edilir
            {
                if ((model.Password == user.Password))
                {
                   FormsAuthentication.SetAuthCookie(model.Username, model.RememberMe);
                   return RedirectToAction("Index", "Home", model);
                }
            }
            //eger kullanici adi veya sifre yanlissa Login ekranına geri dondurulur
            ViewBag.message = "Wrong Password or Wrong Username";
            return View("Login");
        }
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Sign_up(RegisterModel model)
        {
            //burada createNewUser ekranından gelen bilgilerin dogrulugu kontrol edilmeli, sifre olusturulurken iki sifreninde aynı olması gerekli
            MeetingDBContext db = new MeetingDBContext();
            var User = db.Users.FirstOrDefault(x => x.Username == model.Username);
            if (User != null)//bu kullanici adina sahip biri var mi diye kontrol edilir
            {
                ViewBag.message = "somebody has already had this username";//kullanici adi, unique olması gerekiyor bu sistem icin
                return View("Register");
            }
            else
            {
                if (model.Password != model.Rpassword)//eger password ve re-password uyumlu degilse tekrar register ekranina yonlendirilir
                {
                    ViewBag.message = "Password and Re-password does not match";
                    return View("Register");
                }
                else
                {
                    if(model.Username==null || model.Password==null)//kullanici adi ve sifre bos olmamali mutlaka girilmelidir
                    {
                        ViewBag.message = "Empty Field";
                        return View("Register");
                    }
                    User user = new User();
                    user.role = "Not Approved";
                    user.Username = model.Username;
                    user.Password = model.Password;
                    user.Fullname = model.FullName;
                    user.Email = model.Email;
                    //kullanici olusturuldu 
                    db.Users.Add(user);
                    db.SaveChanges();
                    //kullanici veri tabanına kaydedildi...
                    LoginModel b = new LoginModel();
                    //sisteme giris icin loginmodel olusturuldu
                    b.Username = user.Username;
                    b.Password = b.Password;
                    FormsAuthentication.SetAuthCookie(b.Username, model.Check);
                    return RedirectToAction("Index", "Home", b);//sisteme giris yapildi,kullanici ana sayfaya yonlendirilir
                }
            }
        }

        //bir kisinin sistemden cikabilmesi icin oncelikle authenticated olmasi gerekmektedir
        [Authorize]
        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login");
        }
    }
}