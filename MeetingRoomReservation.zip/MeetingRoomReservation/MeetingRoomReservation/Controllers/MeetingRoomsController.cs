﻿using MeetingRoomReservation.Authentication;
using MeetingRoomReservation.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MeetingRoomReservation.Controllers
{
    [_SessionControl]
    public class MeetingRoomsController : Controller
    {
        MeetingDBContext db = new MeetingDBContext();
        // GET: MeetingRooms
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Choose_Location()
        {
            List<Location> locations = db.Locations.ToList();
            return View(locations);
        }
        [HttpPost]
        public ActionResult List_The_MeetingRooms(String Location)
        {
            Location location = db.Locations.FirstOrDefault(x=>x.locationName==Location);
            List<MeetingRoom> meetingRooms = db.MeetingRooms.Where(x => x.LocationID == location.LocationID).ToList();
            return View(meetingRooms);
        }
        public ActionResult Add_New_MeetingRoom()
        {
            List<Location> locations = db.Locations.ToList();
            return View(locations);
        }
        [HttpPost]
        public ActionResult Add_New_MeetingRoom(String Location,MeetingRoom meetingRoom)
        {
            Location location = db.Locations.FirstOrDefault(x => x.locationName == Location);
            meetingRoom.Location = location;
            meetingRoom.LocationID = location.LocationID;
            Boolean isExist=false;//aynı lokasyonda aynı isimde baska bir oda var mı diye kontrol ediyoruz
            foreach(var item in db.MeetingRooms.ToList())
            {
                if (item.LocationID == location.LocationID && meetingRoom.RoomName==item.RoomName)
                {
                    isExist = true;
                    break;
                }
            }
            if (meetingRoom.capacity >= 0)
            {
                if (meetingRoom.RoomName != null)
                {
                    if (!isExist)
                    {
                        db.MeetingRooms.Add(meetingRoom);
                        db.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    ViewBag.message = "There is a room with the same name,Please change the room name!!!";
                }
                else
                {
                    ViewBag.message = "Please enter the Room Name!!!";
                }
            }
            else
            {
                ViewBag.message = "Please, change the capacity of the room!!!";
            }
            return View("Add_New_MeetingRoom",db.Locations.ToList());

        }
        public ActionResult Delete(int? id)
        {
            MeetingRoom meetingRoom = db.MeetingRooms.Find(id);
            meetingRoom.Location = db.Locations.Find(meetingRoom.LocationID);
            List<Meeting> meetings = db.Meetings.Where(x => x.MeetingRoomID == id).ToList();
            foreach(var item in meetings)
            {
                List<UserAndMeeting> userAndMeetings = db.UserAndMeetings.Where(x => x.MeetingID == item.MeetingID).ToList();
                Notification notification = db.Notifications.Where(x => x.MeetingID == item.MeetingID).FirstOrDefault();
                if (notification != null && item.end_of_meeting.CompareTo(DateTime.Now) >= 0)//bu toplanti odasindaki toplantilar icin bildirim gonderilmisse bu toplantinin iptal mesaji gonderilmeli
                {
                    foreach(var item1 in userAndMeetings)//toplantiya katilan kisilere toplanti iptali ile ilgili bildirim gonderilmelidir
                    {
                        if (db.UserAndNotifications.Where(x => x.userID == item1.UserID).Where(y => y.NotificationID == notification.NotificationID).FirstOrDefault() == null)
                        {
                            UserAndNotification temp = new UserAndNotification();
                            temp.NotificationID = notification.NotificationID;
                            temp.userID = item1.UserID;
                            db.UserAndNotifications.Add(temp);
                            db.SaveChanges();
                        }
                    }
                    notification.Message = "The Meeting where is in " +meetingRoom.Location.locationName + "  " + meetingRoom.RoomName +
                                  "  is cancelled!!!";
                    notification.TimeOfSentIt = DateTime.Now;
                }
                db.UserAndMeetings.RemoveRange(userAndMeetings);
                db.Meetings.Remove(item);
            }
            db.MeetingRooms.Remove(meetingRoom);
            db.SaveChanges();
            return RedirectToAction("Choose_Location");
        }
        public ActionResult Edit(int? id)
        {
            MeetingRoom meetingRoom = db.MeetingRooms.Find(id);
            return View(meetingRoom);
        }

        [HttpPost]
        public ActionResult Edit(MeetingRoom meetingRoom)
        {
            MeetingRoom edited_MeetingRoom = db.MeetingRooms.Where(x => x.MeetingRoomID == meetingRoom.MeetingRoomID).FirstOrDefault();
            //guncellenecek olan toplantı odası veri tabanından bulundu
            Boolean isExist = false;
            if (meetingRoom.RoomName != null)
            {
                foreach (var item in db.MeetingRooms.ToList())
                {
                    if ((item.LocationID == edited_MeetingRoom.LocationID && meetingRoom.RoomName == item.RoomName) && meetingRoom.RoomName != edited_MeetingRoom.RoomName)
                    {
                        isExist = true;
                    }
                }
                if (!isExist)              //aynı lokasyonda aynı isimde baska bir oda var mı diye kontrol ediyoruz
                {
                    if (meetingRoom.RoomName != null && meetingRoom.capacity >= 0)
                    {
                        edited_MeetingRoom.RoomName = meetingRoom.RoomName;
                        edited_MeetingRoom.capacity = meetingRoom.capacity;
                        Location location = db.Locations.Find(edited_MeetingRoom.LocationID);
                        List<Meeting> meetings = db.Meetings.Where(x => x.MeetingRoomID == meetingRoom.MeetingRoomID).ToList();
                        foreach (var item in meetings)
                        {
                            Notification notification = db.Notifications.Where(x => x.MeetingID == item.MeetingID).FirstOrDefault();
                            if (notification != null && item.end_of_meeting.CompareTo(DateTime.Now) >= 0)
                            {
                                List<UserAndMeeting> userAndMeetings = db.UserAndMeetings.Where(x => x.MeetingID == item.MeetingID).ToList();
                                //toplantiya katilacak olan kisileri listeye atadik
                                //toplanti katilimcilarindan kendisine gelen bildirimleri silenlere de toplanti guncellemesi ile ilgili bildirim gonderilmeli
                                foreach (var item1 in userAndMeetings)
                                {
                                    if (db.UserAndNotifications.Where(x => x.userID == item1.UserID).Where(y => y.NotificationID == notification.NotificationID).FirstOrDefault() == null)
                                    {
                                        //bu kosul sonucu true ise, kullanici kendisine gelen bildirimi silmis demektir
                                        //bu sebeple tekrardan kullaniciya bildirim gonderilmeli
                                        UserAndNotification userNotification = new UserAndNotification();
                                        userNotification.NotificationID = notification.NotificationID;
                                        userNotification.userID = item1.UserID;
                                        db.UserAndNotifications.Add(userNotification);
                                        db.SaveChanges();
                                    }
                                }
                                String intro = "Location is " + location.locationName + " and Room is " + meetingRoom.RoomName;
                                String date = "Beginning Time: " + item.beginning_of_meeting +
                                    " Ending Time: " + item.end_of_meeting;
                                notification.Message = intro + " " + date;
                                notification.TimeOfSentIt = DateTime.Now;
                            }
                        }
                        db.SaveChanges();
                        return RedirectToAction("Choose_Location");
                    }
                }
                else
                {
                    ViewBag.message = "There is a room with the same name in this location!!!";
                }
            }
            else
            {
                ViewBag.message = "Please enter the room name!!!";
            }
            return View("Edit", meetingRoom);
        }
    }
}